<?php include('header.php');
$id=$_GET['id'];
$mainid=$_GET['mainid'];

?>
<style type="text/css">
	.selected{
font-weight: bold;

}
</style>
		
		<!-- Banner Start -->
		<div class="page-banner">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="banner-text">
							<h1>Products</h1>
							<ul>
								<li><a href="home-layout-1.html">Home</a></li>
								<li><i class="fa fa-angle-right"></i></li>
								<li>Products</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Banner End -->
		
		
		<!-- Blog Start -->
		<section class="blog">
			<div class="container">
				<div class="row">
					<div class="col-md-3">
						
						<!-- Sidebar Container Start -->
						<div class="sidebar">
							
							<div class="widget">
								<h4>Sub Categories</h4>
								<ul>
									<?php									
$sql = "SELECT * FROM sub_cat where main_id_fk=$mainid";
$result = mysqli_query($con, $sql);
while($row2 = mysqli_fetch_assoc($result)) {
$subcatname=$row2['Sub_cat'];
$subid=$row2['scat_id'];
?>
									<li <?php if($subid==$id){echo  "class='selected'";}?>><a href="subcategory.php?id=<?php echo $mainid;?>"><?php echo $subcatname;?></a></li>
									<?php } ?>
								</ul>
							</div>
							
							
							
						</div>
						<!-- Sidebar Container End -->
					
					</div>
					<div class="col-md-9">
						
						<!-- Blog Classic Start -->
						
									<!-- Post Item End -->

									<!-- Post Item Start -->
									<section class="service-v3">
			<div class="container">
				<div class="row">
					<div class="col-md-9">

						

						<div id="mix-container">
																<?php									
$sql = "SELECT * FROM model_details where sub_cat1=$id";
$result = mysqli_query($con, $sql);
while($row2 = mysqli_fetch_assoc($result)) {
$pname=$row2['model_name'];
$pid=$row2['model_id'];
$mainimage=$row2['main_image'];
?>
							<div class="col-md-3 ">
								<div class="inner">
									<div class="thumb">
										<img src="admin/uploads/mainimage/<?php echo $mainimage;?> " alt="">
										<div class="overlay"></div>
									</div>
									<div class="text">
										<h5><a href="product_details.php?id=<?php echo $pid;?>"><?php echo $pname?></a></h5>
										
										
									</div>
								</div>
							</div>
						<?php } ?>
							
							
							
						</div>

					</div>
				</div>
			</div>
		</section>

                                    
                                    
                                    
                                    
                                    
									<!-- Post Item End -->

									<!-- Post Item Start -->
									
									<!-- Post Item End -->

									<!-- Post Item Start -->
									
									<!-- Post Item End -->

									<!-- Post Item Start -->
									
									<!-- Post Item End -->
								</div>

								<div class="col-md-12">
									<div class="pagination">
										
									</div>
								</div>

							</div>
						</div>
						<!-- Blog Classic End -->

					</div>
					

					


				</div>
			</div>
		</section>
		<!-- Blog End -->
<?php include('footer.php'); ?>