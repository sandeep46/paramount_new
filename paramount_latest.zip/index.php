<?php include('header.php'); ?>

		
		<!-- Slider Start -->
		<section class="main-slider">
			<div class="slider">
				<ul class="bxslider">
					<li style="background-image:url(images/slides/bg2.png);">
						<div class="overlay"></div>
						<div class="content">
							<div class="inner tal">
								<!--<h2>
									Health Care
								</h2>
								<h3>
									You Reliable Medical Solution
								</h3>
								<p class="button">
									<a href="#" class="btn btn-flat">View Details</a>
								</p>-->
							</div>
						</div>
					</li>
					<li style="background-image:url(images/slides/bg1.png);">
						<div class="overlay"></div>
						<div class="content">
							
						</div>
					</li>
					<li style="background-image:url(images/slides/bg3.png);">
						<div class="overlay"></div>
						<div class="content">
							
						</div>
					</li>
                    <li style="background-image:url(images/slides/bg4.png);">
						<div class="overlay"></div>
						<div class="content">
							
						</div>
					</li>					
				</ul>
			</div>
		</section>
		<!-- Slider End -->


		<!-- Service Start -->
		<section class="service-v1">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="heading wow fadeInUp">
							<h2><font color="#0BA997"><b>PARAMOUNT HEALTHCARE</b></font> - "A Commitment of Technology"</h2>
							
							<div class="sep"></div>
						</div>
					</div>
				</div>
                
                <!--
				<div class="row">
					<div class="col-sm-6 col-md-4 col-lg-4">
						<div class="item wow fadeInLeft">
							<div class="icon">
								<span class="icon-i-oncology"></span>
							</div>
							<div class="text">
								<div class="inner">
									<h3>Control and reduce your Service Cost</h3>
									
								</div>
							</div>
						</div>
					</div>
					<!--<div class="col-sm-6 col-md-4 col-lg-4">
						<div class="item wow fadeInUp">
							<div class="icon">
								<span class="icon-i-physical-therapy"></span>
							</div>
							<div class="text">
								<div class="inner">
									<h3>Diagnostic & Therapeutic Equipment</h3>
									<p> Eum health cube scriptorem eu, eu aperiri definiebas concludaturque eam.</p>
								</div>
							</div>
						</div>
					</div>-->
                    
                    
                    
 
                                   
                    
                    
					<!--<div class="col-sm-6 col-md-4 col-lg-4">
						<div class="item wow fadeInRight">
							<div class="icon">
								<span class="icon-i-dental"></span>
							</div>
							<div class="text">
								<div class="inner">
									<h3>Improve uptime and peak Equipment Performance</h3>
									
								</div>
							</div>
						</div>
					</div>
					<!--<div class="col-sm-6 col-md-4 col-lg-4">
						<div class="item wow fadeInLeft">
							<div class="icon">
								<span class="icon-i-laboratory"></span>
							</div>
							<div class="text">
								<div class="inner">
									<h3>Laboratory Equipment</h3>
									<p>Ad his diam eirmod persecuti. Eum health cube scriptorem eu, eu aperiri definiebas concludaturque eam.</p>
								</div>
							</div>
						</div>
					</div>-->
					<!--<div class="col-sm-6 col-md-4 col-lg-4">
						<div class="item wow fadeInUp">
							<div class="icon">
								<span class="icon-i-ear-nose-throat"></span>
							</div>
							<div class="text">
								<div class="inner">
									<h3>Meet High Standard of Patient Care </h3>
									
								</div>
							</div>
						</div>
					</div>
					<!--<div class="col-sm-6 col-md-4 col-lg-4">
						<div class="item wow fadeInRight">
							<div class="icon">
								<span class="icon-i-family-practice"></span>
							</div>
							<div class="text">
								<div class="inner">
									<h3>Calibration & Safety Check-up’s</h3>
									<p>Ad his diam eirmod persecuti. Eum health cube scriptorem eu, eu aperiri definiebas concludaturque eam.</p>
								</div>
							</div>
						</div>
					</div>-->
                    
                   <!-- <div class="col-sm-6 col-md-4 col-lg-4">
						<div class="item wow fadeInLeft">
							<div class="icon">
								<span class="icon-i-administration"></span>
							</div>
							<div class="text">
								<div class="inner">
									<h3>Annual Maintenance Contract</h3>
									<p> Eum health cube scriptorem eu, eu aperiri definiebas concludaturque eam.</p>
								</div>
							</div>
						</div>
					</div>
                    
                                          


 
					<div class="col-sm-6 col-md-4 col-lg-4">
						<div class="item wow fadeInUp">
							<div class="icon">
								<span class="icon-i-medical-library"></span>
							</div>
							<div class="text">
								<div class="inner">
									<h3>Comprehensive Maintenance Contract</h3>
									<p> Eum aperiri definiebas concludaturque.</p>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-4 col-lg-4">
						<div class="item wow fadeInRight">
							<div class="icon">
								<span class="icon-i-text-telephone"></span>
							</div>
							<div class="text">
								<div class="inner">
									<h3>On Call Services</h3>
									<p> Eum health cube scriptorem eu, eu aperiri definiebas concludaturque eam.</p>
								</div>
							</div>
						</div>
					</div>-->
                    <div class="col-md-12" style="padding-left:60px;">
                    <img src="images/authors/certifications2.png"/>
                    </div>
              </div>      
			</div>
		</section>
		<!-- Service End -->

		
		<!-- Department Start -->
		<section class="department-v2">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="heading wow fadeInUp">
							<h2>Our Products</h2>
							<p>We have All Major Products to Serve Customers</p>
							<div class="sep"></div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 wow fadeInUp">
						
						<!-- Department Tab Start -->
						<div class="department-tab">

							<ul class="nav nav-tabs col-md-4">
								<li class="active">
                                <a href="#tab1" data-toggle="tab" aria-expanded="true">
                                <span><img src="images/logos/medical.png"></span>
                                Medical Equipments</a></li>
								<li class=""><a href="#tab2" data-toggle="tab" aria-expanded="false">
                                <span><img src="images/logos/radiology.png"></span>Radiology / Imaging</a></li>
								<li class=""><a href="#tab3" data-toggle="tab" aria-expanded="false">
                                <span><img src="images/logos/dental.png"></span>
                                Dental Equipment</a></li>
								<li class=""><a href="#tab4" data-toggle="tab" aria-expanded="false">
                                <span><img src="images/logos/laboratory.png"></span>Laboratory Solutions</a></li>
								<li class=""><a href="#tab5" data-toggle="tab" aria-expanded="false">
                                <span><img src="images/logos/veterinary.png"></span>Veterinary Equipment</a></li>
                                			<li class=""><a href="#tab6" data-toggle="tab" aria-expanded="false">
                                            <span><img src="images/logos/radiation.png"></span>Radiation Protection</a></li>
                                            
                                                  
                                                            <li class=""><a href="#tab7" data-toggle="tab" aria-expanded="false">
                                                            <span><img src="images/logos/ambulance.png"></span>Emergency Ambulance</a></li>
                                                            
                                                            			
							</ul>
							
							<!-- Tab Content Start -->
							<div class="tab-content col-md-8">
								<div class="tab-pane fade active in" id="tab1">
									<div class="row">										
										<div class="col-md-7">
											<div class="department-content">
												<h2>Medical Equipments</h2>
												<p>
													We represents well known international brands in Medical equipment industry , equipments and solutions.
												</p>
												<h3>We offer for:</h3>
												<div class="row">
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
															<li>Diagonostic</li>
															<li>ENT</li>
															<li>Derma</li>
                                                            <li>Endoscope</li>

														</ul>
													</div>
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
															<li>Ophthalmology</li>
															<li>Physiotherapy</li>
															<li>Medical Furniture</li>
                                                            <li>OTP Equipment</li>
														</ul>
													</div>
												</div>
												<p class="button">
													<a href="#">See Details</a>
												</p>											
											</div>
										</div>
										<div class="col-md-5">
											<div class="thumb">
												<img class="img-fullwidth" src="images/departments/w1.jpg" alt="">
											</div>
										</div>
									</div>
								</div>
								<div class="tab-pane fade" id="tab2">
									<div class="row">										
										<div class="col-md-7">
											<div class="department-content">
												<h2>Radiology/ Medical Imaging</h2>
												<p>
													We provide complete turnkey solutions to any Radiology / Medical imaging needs of today's Health care industry. We represent prestigious multinational companies in the industries from US, Germany, India, Japan etc..
												</p>
												<h3>We offer for:</h3>
												<div class="row">
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
															<li>General Radiography</li>
															<li>C-Arm</li>
															<li>Cath-Labs</li>
                                                            <li>Digital Radiography</li>
															<li>Mamography</li>
                                                            <li>IT Solutions</li>
														</ul>
													</div>
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
															<li>Computerised Radiography</li>
															<li>Ultrasound</li>
															<li>Bone Densitometer</li>
                                                            <li>Contrast Delivery Pressure Injector</li>
															
														</ul>
													</div>
												</div>
												<p class="button">
													<a href="#">See Details</a>
												</p>
											</div>
										</div>
										<div class="col-md-5">
											<div class="thumb">
												<img class="img-fullwidth" src="images/departments/w2.jpg" alt="">
											</div>
										</div>
									</div>
								</div>

								<div class="tab-pane fade" id="tab3">
									<div class="row">
										<div class="col-md-7">
											<div class="department-content">
												<h2>Dental Equipment</h2>
												<p>
													We supply a wide range of medical equipments and lab furniture in UAE, offering the best and complete dental surgery setup.
												</p>
												<h3>We offer for:</h3>
												<div class="row">
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
															<li>CAD CAM</li>
															<li>Dental Treatment Unit</li>
															<li>Dental Imaging Unit</li>
                                                            <li>Autoclaves/Hygiene</li>
														</ul>
													</div>
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
															<li>Dental Laser</li>
															<li>Dental Instruments</li>
															<li>Dental Accessories</li>
														</ul>
													</div>
												</div>
												<p class="button">
													<a href="#">See Details</a>
												</p>
											</div>
										</div>
										<div class="col-md-5">
											<div class="thumb">
												<img class="img-fullwidth" src="images/departments/w3.jpg" alt="">
											</div>
										</div>										
									</div>
								</div>

								<div class="tab-pane fade" id="tab4">
									<div class="row">
										<div class="col-md-7">
											<div class="department-content">
												<h2>Laboratory Solutions</h2>
												<p>
													We have a specialised manufacturing facility for lab furniture and equipment like dental cabinets and other medical equipments in UAE. We provide the best innovative ergonomic designs and tailor made solutions according to the need of the facility.
												</p>
												<h3>We offer for:</h3>
												<div class="row">
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
															<li>Clinical Laboratory</li>
															<li>Industrial Laboratory </li>
															
														</ul>
													</div>
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
															
															<li>Educational Laboratory</li>
															<li>Educational Products</li>
														</ul>
													</div>
												</div>
												<p class="button">
													<a href="#">See Details</a>
												</p>
											</div>
										</div>
										<div class="col-md-5">
											<div class="thumb">
												<img class="img-fullwidth" src="images/departments/w4.jpg" alt="">
											</div>
										</div>
									</div>									
								</div>






								<div class="tab-pane fade" id="tab5">
									<div class="row">
										<div class="col-md-7">
											<div class="department-content">
												<h2>Veterinary Equipment</h2>
												<p>
													We do have solutions for the need of veterinarians.
												</p>
												<h3>We offer for:</h3>
												<div class="row">
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
															<li>Vet. X-Ray System</li>
															<li>Vet. Computerized Radiology</li>
															<li>Vet. Imaging Equipment</li>
														</ul>
													</div>
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
																<li>Vet. Surgical Equipment </li>
															<li>Vet. Lab Equipment</li>
															<li>Vet. Furniture and Cages</li>
														</ul>
													</div>
												</div>
												<p class="button">
													<a href="#">See Details</a>
												</p>
											</div>
										</div>
										<div class="col-md-5">
											<div class="thumb">
												<img class="img-fullwidth" src="images/departments/w5.jpg" alt="">
											</div>
										</div>
									</div>
								</div>
                                
                                
                                
                                <div class="tab-pane fade" id="tab6">
									<div class="row">
										<div class="col-md-7">
											<div class="department-content">
												<h2>Radiation Protection</h2>
												<p>
													We provide radiation shielding solutions and supplies for Hospital and Clinic Construction, Industrial NDT, power Generation, Security and Defense, Aerospace and nuclear Industries and Personal Radiation protection for more than 20 years.
												</p>
												<h3>Special Services:</h3>
												<div class="row">
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
                                                        
                                                       <li> Radiation Shielding</li>
<li>Rf Shielding</li>
<li>Lead Sheets</li>
<li>Lead Shielding Doors</li>

															
														</ul>
													</div>
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
															<li>Lead Glass Windows</li>
<li>Leaded Gypsum Boards</li>
<li>Leaded plywood</li>
<li>Lead Storage Cabinets </li>
														</ul>
													</div>
												</div>
												<p class="button">
													<a href="#">See Details</a>
												</p>
											</div>
										</div>
										<div class="col-md-5">
											<div class="thumb">
												<img class="img-fullwidth" src="images/departments/w4.jpg" alt="">
											</div>
										</div>
									</div>									
								</div>

                                <!--<div class="tab-pane fade" id="tab7">
									<div class="row">
										<div class="col-md-7">
											<div class="department-content">
												<h2>Biomedical Engineering</h2>
												<p>
													One Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat, iste, architecto ullam tenetur quia nemo ratione tempora consectetur quos minus ut quo nulla ipsa aliquid neque molestias et qui sunt. Odit, molestiae.
												</p>
												<h3>Special Services:</h3>
												<div class="row">
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
															<li>Special Service Item 1</li>
															<li>Special Service Item 2</li>
															<li>Special Service Item 3</li>
														</ul>
													</div>
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
															<li>Special Service Item 4</li>
															<li>Special Service Item 5</li>
															<li>Special Service Item 6</li>
														</ul>
													</div>
												</div>
												<p class="button">
													<a href="#">See Details</a>
												</p>
											</div>
										</div>
										<div class="col-md-5">
											<div class="thumb">
												<img class="img-fullwidth" src="images/departments/w5.jpg" alt="">
											</div>
										</div>
									</div>
								</div>-->
                                
                                
                                <div class="tab-pane fade" id="tab7">
									<div class="row">
										<div class="col-md-7">
											<div class="department-content">
												<h2>Emergency Ambulance</h2>
												<p>
													We supply a wide range of Emergency medical Equipments and Ambulances.
												</p>
												<h3>We offer for:</h3>
												<div class="row">
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
															<li>Emergency Medical Equipment</li>
														
														</ul>
													</div>
													<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
														<ul>
															<li>Ambulances</li>
														
														</ul>
													</div>
												</div>
												<p class="button">
													<a href="#">See Details</a>
												</p>
											</div>
										</div>
										<div class="col-md-5">
											<div class="thumb">
												<img class="img-fullwidth" src="images/departments/w5.jpg" alt="">
											</div>
										</div>
									</div>
								</div>
                                
							</div>
							<!-- Tab Content End -->
						</div>
						<!-- Department Tab End -->


					</div>
				</div>
			</div>
		</section>
		<!-- Department End -->



		<!-- Doctors Start 
		<section class="doctor-v1">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="heading wow fadeInUp">
							<h2>Our Qualified Doctors</h2>
							<p>Meet with All Our Qualified Doctors</p>
							<div class="sep"></div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						
						<!-- Doctor Carousel Start 
						<div class="doctor-carousel">

							<div class="item wow fadeInUp">
								<div class="thumb">
									<img src="images/doctors/1.jpg" alt="">
									<div class="overlay"></div>
									<div class="social-icons">
										<ul>
											<li><a href="#"><i class="fa fa-facebook"></i></a></li>
											<li><a href="#"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										</ul>
									</div>
								</div>
								<div class="text">
									<h3><a href="#">Dr. Robin Cook</a></h3>
									<p>Neurosurgeon</p>
								</div>
							</div>


							<div class="item wow fadeInUp">
								<div class="thumb">
									<img src="images/doctors/2.jpg" alt="">
									<div class="overlay"></div>
									<div class="social-icons">
										<ul>
											<li><a href="#"><i class="fa fa-facebook"></i></a></li>
											<li><a href="#"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										</ul>
									</div>
								</div>
								<div class="text">
									<h3><a href="#">Dr. Bob Smith</a></h3>
									<p>Dentist</p>
								</div>
							</div>

							<div class="item wow fadeInUp">
								<div class="thumb">
									<img src="images/doctors/3.jpg" alt="">
									<div class="overlay"></div>
									<div class="social-icons">
										<ul>
											<li><a href="#"><i class="fa fa-facebook"></i></a></li>
											<li><a href="#"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										</ul>
									</div>
								</div>
								<div class="text">
									<h3><a href="#">Dr. Erica Frank</a></h3>
									<p>Cardiologist</p>
								</div>
							</div>


							<div class="item wow fadeInUp">
								<div class="thumb">
									<img src="images/doctors/4.jpg" alt="">
									<div class="overlay"></div>
									<div class="social-icons">
										<ul>
											<li><a href="#"><i class="fa fa-facebook"></i></a></li>
											<li><a href="#"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										</ul>
									</div>
								</div>
								<div class="text">
									<h3><a href="#">Dr. Emily Stowe</a></h3>
									<p>Gynecologist</p>
								</div>
							</div>


							<div class="item wow fadeInUp">
								<div class="thumb">
									<img src="images/doctors/1.jpg" alt="">
									<div class="overlay"></div>
									<div class="social-icons">
										<ul>
											<li><a href="#"><i class="fa fa-facebook"></i></a></li>
											<li><a href="#"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										</ul>
									</div>
								</div>
								<div class="text">
									<h3><a href="#">Dr. Robin Cook</a></h3>
									<p>Neurosurgeon</p>
								</div>
							</div>


							<div class="item wow fadeInUp">
								<div class="thumb">
									<img src="images/doctors/2.jpg" alt="">
									<div class="overlay"></div>
									<div class="social-icons">
										<ul>
											<li><a href="#"><i class="fa fa-facebook"></i></a></li>
											<li><a href="#"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										</ul>
									</div>
								</div>
								<div class="text">
									<h3><a href="#">Dr. Bob Smith</a></h3>
									<p>Dentist</p>
								</div>
							</div>

							<div class="item wow fadeInUp">
								<div class="thumb">
									<img src="images/doctors/3.jpg" alt="">
									<div class="overlay"></div>
									<div class="social-icons">
										<ul>
											<li><a href="#"><i class="fa fa-facebook"></i></a></li>
											<li><a href="#"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										</ul>
									</div>
								</div>
								<div class="text">
									<h3><a href="#">Dr. Erica Frank</a></h3>
									<p>Cardiologist</p>
								</div>
							</div>


							<div class="item wow fadeInUp">
								<div class="thumb">
									<img src="images/doctors/4.jpg" alt="">
									<div class="overlay"></div>
									<div class="social-icons">
										<ul>
											<li><a href="#"><i class="fa fa-facebook"></i></a></li>
											<li><a href="#"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										</ul>
									</div>
								</div>
								<div class="text">
									<h3><a href="#">Dr. Emily Stowe</a></h3>
									<p>Gynecologist</p>
								</div>
							</div>

							
						</div>
						<!-- Doctor Carousel End 

					</div>
				</div>
			</div>
		</section>
		<!-- Doctors End -->


		
		<!-- Quote Start -->
		<section class="quote-v1 parallax parallax-1">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-sm-6">
						<div class="quote-text wow fadeInLeft">
							One point contact for all your Medical Equipment Service needs…...
						</div>
					</div>
					<div class="col-md-4 col-sm-6">
						<div class="quote-button wow fadeInRight">
							<a href="#">Contact Us</a>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Quote End -->



		<!-- Pricing Start
		<section class="pricing-v1">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="heading wow fadeInUp">
							<h2>Pricing</h2>
							<p>We are Offering Special Discounts Now</p>
							<div class="sep"></div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-4">
						<div class="pricing-item wow fadeInLeft">
							<div class="title">BASIC PLAN</div>
							<div class="subtitle">30 Days Free Trial</div>
							<div class="price">
								<div class="hexa">
									<div class="amount"><span>$</span>29</div>
									<div class="time">per month</div>
								</div>
							</div>
							<div class="offer">
								<ul>
									<li>6 Specialties</li>
									<li>30 Tests and Treatments</li>
									<li>1 Medical Consultation</li>
									<li>1 Home Visit</li>
									<li>No Pregnancy Care</li>
									<li>No Assistance</li>
								</ul>
							</div>
							<div class="button">
								<a href="#">Select</a>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="pricing-item wow fadeInUp">
							<div class="title">GOLD PLAN</div>
							<div class="subtitle">Payable in every 6 month</div>
							<div class="price">
								<div class="hexa">
									<div class="amount"><span>$</span>69</div>
									<div class="time">per month</div>
								</div>
							</div>
							<div class="offer">
								<ul>
									<li>12 Specialties</li>
									<li>90 Tests and Treatments</li>
									<li>2 Medical Consultation</li>
									<li>2 Home Visit</li>
									<li>Available Pregnancy Care</li>
									<li>24 Hours Assistance</li>
								</ul>
							</div>
							<div class="button">
								<a href="#">Select</a>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="pricing-item wow fadeInRight">
							<div class="title">DIAMOND PLAN</div>
							<div class="subtitle">Payable in every year</div>
							<div class="price">
								<div class="hexa">
									<div class="amount"><span>$</span>99</div>
									<div class="time">per month</div>
								</div>
							</div>
							<div class="offer">
								<ul>
									<li>24 Specialties</li>
									<li>160 Tests and Treatments</li>
									<li>4 Medical Consultation</li>
									<li>4 Home Visit</li>
									<li>Available Pregnancy Care</li>
									<li>24 Hours Assistance</li>
								</ul>
							</div>
							<div class="button">
								<a href="#">Select</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Pricing End -->



		<!-- Testimonial Start
		<section class="testimonial-v1">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="heading wow fadeInUp">
							<h2>Testimonial</h2>
							<p>Our Happy Clients Tell About Us</p>
							<div class="sep sep-white"></div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						
						<!-- Testimonial Carousel Start 
						<div class="testimonial-carousel wow fadeInUp">
							<div class="item">
								<div class="testimonial-wrapper">								
									<div class="content">
										<div class="comment">
											<p>
												“Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.”
											</p>
											<div class="icon"></div>
										</div>
										<div class="author">
											<div class="photo">
												<img src="images/testimonial/2.jpg" alt="">
											</div>
											<div class="text">
												<h3>JOHN DOE </h3>
												<h4>Managing Director <span>(ABC Inc.)</span></h4>
											</div>
										</div>										
									</div>
								</div>
							</div>
							<div class="item">
								<div class="testimonial-wrapper">								
									<div class="content">
										<div class="comment">
											<p>
												“Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.”
											</p>
											<div class="icon"></div>
										</div>
										<div class="author">
											<div class="photo">
												<img src="images/testimonial/3.jpg" alt="">
											</div>
											<div class="text">
												<h3>JOHN DOE </h3>
												<h4>CEO <span>(XYZ Ltd.)</span></h4>
											</div>
										</div>										
									</div>
								</div>
							</div>
						</div>
						<!-- Testimonial Carousel End

					</div>
				</div>
			</div>
		</section>
		<!-- Testimonial End -->




		<!-- News Start -->
		<section class="news-v1">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="heading wow fadeInUp">
							<h2>Latest News</h2>
							<p>See All Our Updated and Latest News</p>
							<div class="sep"></div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						
						<!-- News Carousel Start -->
						<div class="news-carousel">

							<div class="item wow fadeInUp">
								<div class="thumb">
									<img src="images/news/1.jpg" alt="">
									<div class="date">
										<div class="day">25</div>
										<div class="month">Sep</div>
									</div>
								</div>
								<div class="text">
									<h3><a href="#">News Title Here</a></h3>
									<h4><i class="fa fa-comments-o" aria-hidden="true"></i> 24 Comments</h4>
									<p>
										In pede quis wisi accumsan, et posuere ac, lectus morbi hendrerit auctor aliquet sed orci, in condimentum faucibus congue vel.
									</p>
								</div>
							</div>

							<div class="item wow fadeInUp">
								<div class="thumb">
									<img src="images/news/2.jpg" alt="">
									<div class="date">
										<div class="day">11</div>
										<div class="month">Aug</div>
									</div>
								</div>
								<div class="text">
									<h3><a href="#">News Title Here</a></h3>
									<h4><i class="fa fa-comments-o" aria-hidden="true"></i> 24 Comments</h4>
									<p>
										In pede quis wisi accumsan, et posuere ac, lectus morbi hendrerit auctor aliquet sed orci, in condimentum faucibus congue vel.
									</p>
								</div>
							</div>

							<div class="item wow fadeInUp">
								<div class="thumb">
									<img src="images/news/3.jpg" alt="">
									<div class="date">
										<div class="day">28</div>
										<div class="month">Jun</div>
									</div>
								</div>
								<div class="text">
									<h3><a href="#">News Title Here</a></h3>
									<h4><i class="fa fa-comments-o" aria-hidden="true"></i> 24 Comments</h4>
									<p>
										In pede quis wisi accumsan, et posuere ac, lectus morbi hendrerit auctor aliquet sed orci, in condimentum faucibus congue vel.
									</p>
								</div>
							</div>

							<div class="item wow fadeInUp">
								<div class="thumb">
									<img src="images/news/1.jpg" alt="">
									<div class="date">
										<div class="day">25</div>
										<div class="month">Sep</div>
									</div>
								</div>
								<div class="text">
									<h3><a href="#">News Title Here</a></h3>
									<h4><i class="fa fa-comments-o" aria-hidden="true"></i> 24 Comments</h4>
									<p>
										In pede quis wisi accumsan, et posuere ac, lectus morbi hendrerit auctor aliquet sed orci, in condimentum faucibus congue vel.
									</p>
								</div>
							</div>

							<div class="item wow fadeInUp">
								<div class="thumb">
									<img src="images/news/2.jpg" alt="">
									<div class="date">
										<div class="day">11</div>
										<div class="month">Aug</div>
									</div>
								</div>
								<div class="text">
									<h3><a href="#">News Title Here</a></h3>
									<h4><i class="fa fa-comments-o" aria-hidden="true"></i> 24 Comments</h4>
									<p>
										In pede quis wisi accumsan, et posuere ac, lectus morbi hendrerit auctor aliquet sed orci, in condimentum faucibus congue vel.
									</p>
								</div>
							</div>

							<div class="item wow fadeInUp">
								<div class="thumb">
									<img src="images/news/3.jpg" alt="">
									<div class="date">
										<div class="day">28</div>
										<div class="month">Jun</div>
									</div>
								</div>
								<div class="text">
									<h3><a href="#">News Title Here</a></h3>
									<h4><i class="fa fa-comments-o" aria-hidden="true"></i> 24 Comments</h4>
									<p>
										In pede quis wisi accumsan, et posuere ac, lectus morbi hendrerit auctor aliquet sed orci, in condimentum faucibus congue vel.
									</p>
								</div>
							</div>
							
						</div>
						<!-- News Carousel End -->

					</div>
				</div>
			</div>
		</section>
		<!-- News End -->

			

		<!-- Partner Start -->
		<section class="partner-v1">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="heading wow fadeInUp">
							<h2>Our Partners</h2>
							<p>All Our Company Partners are Listed Below</p>
							<div class="sep"></div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
							
						<div class="partner-carousel">
							<div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/1.png" alt=""></a>
								</div>
							</div>
							<div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/2.png" alt=""></a>
								</div>
							</div>
							<div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/3.png" alt=""></a>
								</div>
							</div>
							<div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/4.png" alt=""></a>
								</div>
							</div>
							<div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/5.png" alt=""></a>
								</div>
							</div>
                            <div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/6.png" alt=""></a>
								</div>
							</div>
                            <div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/7.png" alt=""></a>
								</div>
							</div>
							<div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/1.png" alt=""></a>
								</div>
							</div>
							<div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/2.png" alt=""></a>
								</div>
							</div>
							<div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/3.png" alt=""></a>
								</div>
							</div>
							<div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/4.png" alt=""></a>
								</div>
							</div>
							<div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/5.png" alt=""></a>
								</div>
							</div>
                            <div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/6.png" alt=""></a>
								</div>
							</div>
                            <div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/7.png" alt=""></a>
								</div>
							</div>
							<div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/1.png" alt=""></a>
								</div>
							</div>
							<div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/2.png" alt=""></a>
								</div>
							</div>
                            
                            <div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/3.png" alt=""></a>
								</div>
							</div>
							<div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/4.png" alt=""></a>
								</div>
							</div>
                            <div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/5.png" alt=""></a>
								</div>
							</div>
                            <div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/6.png" alt=""></a>
								</div>
							</div>
                            <div class="item wow fadeInUp">
								<div class="inner">
									<a href="#"><img src="images/partner/7.png" alt=""></a>
								</div>
							</div>
                            
						</div>

					</div>
				</div>
			</div>
		</section>
		<!-- Partner End -->

<?php include('footer.php'); ?>